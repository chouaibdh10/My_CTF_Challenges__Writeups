// Mozilla User Preferences
user_pref("browser.startup.homepage", "https://github.com");
user_pref("browser.search.defaultenginename", "Google");
user_pref("browser.urlbar.placeholderName", "Google");
user_pref("browser.download.dir", "/home/coco/Downloads");
user_pref("browser.download.folderList", 1);
user_pref("browser.download.useDownloadDir", true);
user_pref("browser.sessionstore.resume_from_crash", true);
user_pref("browser.tabs.warnOnClose", true);
user_pref("extensions.screenshots.disabled", true);
user_pref("privacy.donottrackheader.enabled", true);
user_pref("signon.rememberSignons", true);
user_pref("widget.content.gtk-theme-override", "Adwaita:dark");
