# ~/.bash_logout: executed when login shell exits.

if [ "$SHLVL" = 1 ]; then
    clear
fi
