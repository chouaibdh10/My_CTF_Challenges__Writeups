DO NOT DELETE - DATABASE RECOVERY
This WAL file was salvaged from a filesystem recovery operation.
Contains pre-deletion state of opencode sessions.
Analyze with: sqlite3 opencode.db ".recover" --wal=opencode.db-wal
