# Old assignment - deleted
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)  # too slow, switched to iterative
