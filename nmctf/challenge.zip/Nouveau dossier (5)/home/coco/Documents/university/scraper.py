#!/usr/bin/env python3
"""
Web scraper for research project - collecting data from academic sources
"""

import requests
from bs4 import BeautifulSoup
import csv
import time

def scrape_page(url):
    """Scrape a single page and extract data"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract title
        title = soup.find('h1')
        title_text = title.get_text(strip=True) if title else 'N/A'
        
        # Extract abstract
        abstract = soup.find('div', class_='abstract')
        abstract_text = abstract.get_text(strip=True) if abstract else 'N/A'
        
        # Extract authors
        authors = soup.find_all('span', class_='author')
        author_list = [a.get_text(strip=True) for a in authors]
        
        return {
            'title': title_text,
            'authors': ', '.join(author_list),
            'abstract': abstract_text,
            'url': url
        }
        
    except Exception as e:
        print(f"Error scraping {url}: {e}")
        return None

def main():
    urls = [
        'https://example.com/paper1',
        'https://example.com/paper2',
        'https://example.com/paper3'
    ]
    
    results = []
    for url in urls:
        data = scrape_page(url)
        if data:
            results.append(data)
        time.sleep(1)  # Be polite
    
    # Save to CSV
    with open('research_data.csv', 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['title', 'authors', 'abstract', 'url'])
        writer.writeheader()
        writer.writerows(results)
    
    print(f"Scraped {len(results)} papers")

if __name__ == '__main__':
    main()
