#!/usr/bin/env python3
"""
Template for new Python scripts.
"""
import sys

def main():
    print("Hello, World!")
    return 0

if __name__ == "__main__":
    sys.exit(main())
